
// Re-export from the hooks implementation
import { useToast, toast } from "@/hooks/use-toast";

export { useToast, toast };
